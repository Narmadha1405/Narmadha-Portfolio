# Narmadha Balamurugan — Portfolio

Pastel lavender, blush pink and sage-green React portfolio.

## Run locally
1. Install Node.js LTS.
2. Open this folder in VS Code (the folder containing `package.json`).
3. In the VS Code terminal, run `npm install`.
4. Run `npm run dev`.
5. Open the localhost URL printed by Vite.

## Included
- React + Vite + CSS
- Profile photo and resume PDF
- Four project cards linked to the supplied GitHub repositories
