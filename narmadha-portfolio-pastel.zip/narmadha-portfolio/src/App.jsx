import { useEffect, useState } from 'react';
import profilePhoto from './assets/narmadha-profile.png';
import {
  ArrowDown, ArrowUpRight, Github, Linkedin, Mail, Menu, X, Code2,
  Database, BrainCircuit, Monitor, BriefcaseBusiness, GraduationCap,
  Trophy, ExternalLink, Sparkles, Download, MapPin
} from 'lucide-react';

const projects = [
  { number:'01', title:'Causal Responsibility Scoring for Urban Air Pollution', category:'AI / DATA VISUALIZATION', description:'An interactive air-quality dashboard featuring AQI monitoring, pollutant analysis, maps, time-series visualizations, SHAP-based source contributions and counterfactual policy simulation.', stack:['Streamlit','Flask','Data Visualization','SHAP'], accent:'blue', icon:BrainCircuit, note:'View repository', link:'https://github.com/Narmadha1405/Causal-Responsibility-Scoring-For-Urban-Air-Pollution' },
  { number:'02', title:'Symbiosis — Waste-to-Resource Platform', category:'FRONTEND DEVELOPMENT', description:'A web-based platform connecting waste providers with seekers to encourage reuse of natural and organic waste, with requirement-based matching by type, quantity, intended usage and location.', stack:['HTML','CSS','JavaScript','Bootstrap'], accent:'green', icon:Sparkles, note:'View repository', link:'https://github.com/Narmadha1405/Symbiosis' },
  { number:'03', title:'Retail Point of Sale System', category:'BACKEND DEVELOPMENT', description:'A retail POS application for product management, inventory tracking and sales operations, including stock validation, inventory updates after purchases and sales history tracking.', stack:['Java','Spring Boot','MySQL','HTML','CSS'], accent:'purple', icon:Database, note:'View repository', link:'https://github.com/Narmadha1405/Retail-Point-of-Sale-POS-system' },
  { number:'04', title:'Smart Weather-Based Crop Recommendation', category:'WEB APPLICATION', description:'A weather-aware crop recommendation project built with a weather API to support crop selection.', stack:['HTML','Bootstrap','Weather API'], accent:'blue', icon:Sparkles, note:'View repository', link:'https://github.com/Narmadha1405/Smart-Weather-Based-Crop-Recommendation-System' }
];

const skills = [
  { title: 'Frontend', icon: Monitor, items: ['HTML', 'CSS', 'JavaScript', 'React.js', 'Bootstrap'] },
  { title: 'Backend', icon: Code2, items: ['Java', 'Spring Boot', 'Python', 'Flask', 'REST APIs'] },
  { title: 'Database & Tools', icon: Database, items: ['MySQL', 'Git', 'GitHub', 'NetBeans', 'VS Code'] },
  { title: 'AI / ML', icon: BrainCircuit, items: ['Machine Learning Basics', 'Random Forest', 'SHAP', 'Streamlit', 'Data Visualization'] }
];

const socials = [
  { label: 'GitHub', href: 'https://github.com/Narmadha1405', icon: Github },
  { label: 'LinkedIn', href: 'https://www.linkedin.com/in/narmadha-balamurugan-54494228a/', icon: Linkedin },
  { label: 'Email', href: 'mailto:narmathabalamurgan@gmail.com', icon: Mail }
];

function App() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [active, setActive] = useState('Home');
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => {
      setScrolled(window.scrollY > 24);
      const sections = ['home', 'about', 'skills', 'projects', 'experience', 'contact'];
      const current = sections.map(id => document.getElementById(id)).filter(Boolean)
        .filter(el => el.getBoundingClientRect().top <= 150).pop();
      if (current) setActive(current.id[0].toUpperCase() + current.id.slice(1));
    };
    window.addEventListener('scroll', onScroll);
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const closeMenu = () => setMenuOpen(false);
  const navItems = ['Home', 'About', 'Skills', 'Projects', 'Experience', 'Contact'];

  return (
    <div className="site-shell">
      <div className="ambient ambient-one" /><div className="ambient ambient-two" />
      <header className={`navbar ${scrolled ? 'navbar-scrolled' : ''}`}>
        <a className="brand" href="#home" onClick={closeMenu}><span className="brand-mark">N.</span><span>NARMADHA<span className="brand-dot">.</span></span></a>
        <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)} aria-label="Toggle navigation">{menuOpen ? <X /> : <Menu />}</button>
        <nav className={menuOpen ? 'nav-links nav-open' : 'nav-links'}>
          {navItems.map(item => <a key={item} className={active === item ? 'nav-active' : ''} href={`#${item.toLowerCase()}`} onClick={closeMenu}>{item}</a>)}
          <a className="nav-cta" href="mailto:narmathabalamurgan@gmail.com">Let's talk <ArrowUpRight size={15} /></a>
        </nav>
      </header>

      <main>
        <section className="hero section-wrap" id="home">
          <div className="hero-copy reveal">
            <div className="eyebrow"><span className="status-dot" /> AVAILABLE FOR OPPORTUNITIES</div>
            <p className="hero-pretitle">Hello, I'm</p>
            <h1>Narmadha<br /><span>Balamurugan.</span></h1>
            <h2>Full Stack Developer <i>+</i> AI/ML Enthusiast</h2>
            <p className="hero-description">I enjoy building thoughtful web experiences and exploring intelligent solutions that turn ideas into useful products.</p>
            <div className="hero-actions">
              <a className="button button-primary" href="#projects">Explore my work <ArrowUpRight size={17} /></a>
              <a className="button button-ghost" href="/Narmadha-Balamurugan-Resume.pdf" download>Download resume <Download size={16} /></a>
            </div>
            <div className="hero-socials">{socials.map(({ label, href, icon: Icon }) => <a key={label} href={href} target={label === 'Email' ? undefined : '_blank'} rel="noreferrer" aria-label={label}><Icon size={18} /></a>)}<span className="social-line" /><span className="location"><MapPin size={14} /> Tamil Nadu, India</span></div>
          </div>
          <div className="hero-visual reveal reveal-delay">
            <div className="orbit orbit-one" /><div className="orbit orbit-two" />
            <div className="profile-frame"><img className="profile-photo" src={profilePhoto} alt="Narmadha Balamurugan" /></div>
            <div className="floating-card card-code"><Code2 size={17} /><span><b>Build</b><small>Web experiences</small></span></div>
            <div className="floating-card card-ai"><BrainCircuit size={18} /><span><b>Explore</b><small>Intelligent solutions</small></span></div>
            <div className="visual-caption">CURIOUS MIND. CONTINUOUS LEARNING.</div>
          </div>
          <a className="scroll-cue" href="#about"><span>SCROLL TO EXPLORE</span><ArrowDown size={15} /></a>
        </section>

        <section className="section-wrap section-block" id="about">
          <div className="section-heading"><span className="section-kicker">01 / A LITTLE INTRO</span><h2>About <span>me</span></h2></div>
          <div className="about-grid">
            <div className="about-main"><p className="lead">A developer who loves learning, building, and solving problems.</p><p>I'm Narmadha, a Computer Science and Business Systems student at M. Kumarasamy College of Engineering. My interests bring together full stack development and AI/ML, and I enjoy turning concepts into practical, user-focused applications.</p><p>Through projects, internships and hackathons, I've been building my foundation in software development while continuously exploring new technologies.</p><div className="about-links"><a href="https://github.com/Narmadha1405" target="_blank" rel="noreferrer">Explore GitHub <ArrowUpRight size={15} /></a><a href="https://www.linkedin.com/in/narmadha-balamurugan-54494228a/" target="_blank" rel="noreferrer">Connect on LinkedIn <ArrowUpRight size={15} /></a></div></div>
            <div className="education-card"><div className="card-icon"><GraduationCap size={21} /></div><span className="mini-label">EDUCATION</span><h3>B.Tech — Computer Science and Business Systems</h3><p>M. Kumarasamy College of Engineering, Karur</p><div className="education-meta"><span>2023 — 2027</span><span>Undergraduate</span></div></div>
          </div>
        </section>

        <section className="section-wrap section-block" id="skills">
          <div className="section-heading"><span className="section-kicker">02 / WHAT I WORK WITH</span><h2>Skills & <span>toolkit</span></h2><p>A growing toolkit across development and intelligent applications.</p></div>
          <div className="skills-grid">{skills.map(({ title, icon: Icon, items }, index) => <article className="skill-card" key={title}><div className="skill-card-top"><span className="card-icon"><Icon size={20} /></span><span className="skill-index">0{index + 1}</span></div><h3>{title}</h3><div className="tag-list">{items.map(item => <span className="tag" key={item}>{item}</span>)}</div></article>)}</div>
        </section>

        <section className="section-wrap section-block" id="projects">
          <div className="section-heading heading-row"><div><span className="section-kicker">03 / SELECTED WORK</span><h2>Featured <span>projects</span></h2><p>A few things I've worked on and learned from.</p></div><a className="text-link" href="https://github.com/Narmadha1405" target="_blank" rel="noreferrer">More on GitHub <ArrowUpRight size={16} /></a></div>
          <div className="projects-grid">{projects.map(project => { const Icon = project.icon; return <article className={`project-card project-${project.accent}`} key={project.number}><div className="project-top"><span className="project-number">{project.number} / 04</span><span className="project-symbol"><Icon size={23} /></span></div><span className="project-category">{project.category}</span><h3>{project.title}</h3><p>{project.description}</p><div className="tag-list">{project.stack.map(item => <span className="tag" key={item}>{item}</span>)}</div><div className="project-footer"><span>{project.note}</span><a href={project.link} target="_blank" rel="noreferrer" aria-label={`View ${project.title} on GitHub`}><ArrowUpRight size={18} /></a></div></article>})}</div>
        </section>

        <section className="section-wrap section-block" id="experience">
          <div className="section-heading"><span className="section-kicker">04 / THE JOURNEY SO FAR</span><h2>Experience & <span>highlights</span></h2></div>
          <div className="timeline"><div className="timeline-item"><div className="timeline-marker"><BriefcaseBusiness size={17} /></div><div className="timeline-content"><div className="timeline-meta"><span>INTERNSHIP</span><span>JULY 2025</span></div><h3>Full Stack Development Intern</h3><p className="timeline-company">Elysium Technologies Private Limited</p><p>Gained practical exposure to web development using HTML, CSS and JavaScript, and worked with development tools in an internship environment.</p></div></div><div className="timeline-item"><div className="timeline-marker"><Trophy size={17} /></div><div className="timeline-content"><div className="timeline-meta"><span>HACKATHON</span><span>48-HOUR EVENT</span></div><h3>TRANSENSE</h3><p>Participated in a 48-hour hackathon, collaborating under time constraints and developing problem-solving and teamwork skills.</p></div></div><div className="timeline-item"><div className="timeline-marker"><Trophy size={17} /></div><div className="timeline-content"><div className="timeline-meta"><span>HACKATHON</span><span>24-HOUR EVENT</span></div><h3>Symbiosis</h3><p>Participated in a 24-hour hackathon at K. Ramakrishna College of Engineering.</p></div></div></div>
          <div className="cert-panel"><div><span className="mini-label">CERTIFICATIONS & LEARNING</span><h3>Always learning something new.</h3></div><div className="cert-list"><span>ServiceNow Certified System Administrator (CSA)</span><span>Google Student Ambassador — Gemini AI Initiatives</span><span>TCS iON — Interview Skills</span><span>Google Cloud — Digital Transformation</span><span>NPTEL — Entrepreneurship</span><span>NPTEL — The Joy of Computing Using Python</span></div></div>
        </section>

        <section className="contact-section" id="contact"><div className="section-wrap contact-inner"><span className="section-kicker">05 / LET'S CONNECT</span><h2>Have an idea?<br /><span>Let's build something.</span></h2><p>I'm interested in opportunities where I can learn, contribute and grow as a developer.</p><a className="button button-primary contact-button" href="mailto:narmathabalamurgan@gmail.com">Say hello <ArrowUpRight size={17} /></a><div className="contact-socials">{socials.map(({ label, href, icon: Icon }) => <a key={label} href={href} target={label === 'Email' ? undefined : '_blank'} rel="noreferrer"><Icon size={17} /> {label}</a>)}</div></div></section>
      </main>
      <footer className="footer"><a className="brand" href="#home"><span className="brand-mark">N.</span><span>NARMADHA<span className="brand-dot">.</span></span></a><span>Designed & built with curiosity.</span><span>© {new Date().getFullYear()} Narmadha Balamurugan</span></footer>
      <a className="back-top" href="#home" aria-label="Back to top"><ArrowUpRight size={18} /></a>
    </div>
  );
}

export default App;
